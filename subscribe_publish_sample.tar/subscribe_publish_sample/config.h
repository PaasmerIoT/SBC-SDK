/*here give gpio pins based on wiring pi gpio pin structure*/

#define UserName "demopaasmer@gmail.com" //your user name in website

#define DeviceName "raspberry" //your device name
//#define UserName ""
//#define DeviceName ""

#define feedname1 "feed1" //feed name you use in the website

#define sensorpin1 1 //modify with the pin number which you connected the sensor

#define feedname2 "feed2" //feed name you use in the website

#define sensorpin2 1 //modify with the pin number which you connected the sensor

#define feedname3 "" //feed name you use in the website

#define sensorpin3 1 //modify with the pin number which you connected the sensor

#define feedname4 "" //feed name you use in the website

#define sensorpin4 1 //modify with the pin number which you connected the sensor

#define controlfeedname1 "controlfeed1" //feed name you use in the website for control device pins

#define controlpin1 1 //modify with the pin number which you connected the control device (eg.: motor)

#define controlfeedname2 "controlfeed2" //feed name you use in the website for control device pins

#define controlpin2 1 //modify with the pin number which you connected the control device (eg.: motor)

#define timePeriod 10 //change the time delay as you required for sending sensor values to paasmer cloud
